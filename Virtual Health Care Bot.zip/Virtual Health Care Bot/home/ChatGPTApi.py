import requests
import json

class ChatGPTApi:
    OPENAI_API_KEY = "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"
    URL = "https://api.openai.com/v1/chat/completions"

    @staticmethod
    def run(user_message):
        headers = {
            "Authorization": f"Bearer {ChatGPTApi.OPENAI_API_KEY}",
            "Content-Type": "application/json",
        }

        data = {
            "model": "gpt-3.5-turbo",
            "messages": [{"role": "user", "content": user_message}],
        }

        try:
            response = requests.post(
                ChatGPTApi.URL, headers=headers, data=json.dumps(data)
            )

            response.raise_for_status()  # Raise an error for bad responses

            return response.text

        except requests.exceptions.RequestException as e:
            return str(e)


