import json
import re

class ChatGPTResultParser:
    @staticmethod
    def parse_result(result):
        # Parse the JSON result
        result_json = json.loads(result)
        choices = result_json.get("choices", [])
        if not choices:
            return None

        first_choice = choices[0]
        message = first_choice.get("message", {})
        content = message.get("content", "")

        return content

def extract_meal_lists(content):
    breakfast_list, lunch_list, evening_snack_list, dinner_list, exercises_list = [], [], [], [], []

    pattern_string = "<s>\\s*(.*?)\\s*<e>"
    pattern = re.compile(pattern_string, re.DOTALL)
    matcher = pattern.finditer(content)

    for match in matcher:
        lines = match.group(1).strip().split("\n")
        if lines:
            key = lines[0].strip()
            for line in lines[1:]:
                food = line.strip()  
                
                if key == "1. Breakfast":
                    breakfast_list.append(food.replace('-','').lstrip().rstrip())
                elif key == "2. Lunch":
                    lunch_list.append(food.replace('-','').lstrip().rstrip())
                elif key == "3. Evening Snack":
                    evening_snack_list.append(food.replace('-','').lstrip().rstrip())
                elif key == "4. Dinner":
                    dinner_list.append(food.replace('-','').lstrip().rstrip())
                elif key == "5. Exercises":
                    exercises_list.append(food.replace('-','').lstrip().rstrip())

    return breakfast_list, lunch_list, evening_snack_list, dinner_list, exercises_list

