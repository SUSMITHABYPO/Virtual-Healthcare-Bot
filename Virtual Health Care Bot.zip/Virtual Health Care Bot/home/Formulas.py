from decimal import Decimal, ROUND_DOWN

def TDEE(age, weight, height, gender):
    age2 = float(age)
    height2 = float(height)
    weight2 = float(weight)

    bmr = 0.0
    tdee = 0.0

    # Convert strings to lowercase for case-insensitive comparison
    gender_lower = gender.lower()
    
    # TDEE for female
    if gender_lower == "female":
        bmr = 655 + (9.6 * weight2) + (1.8 * height2) - (4.7 * age2)
        tdee = bmr * 1.725
    # TDEE for male
    else:
        bmr = 66 + (13.7 * weight2) + (5 * height2) - (6.8 * age2)
        tdee = bmr * 1.725


    result = Decimal(tdee).quantize(Decimal("0"), rounding=ROUND_DOWN)
    return str(result)




def generate_formatted_string(user_dict):
    user_birth_year = user_dict.get("userbyear", "")
    user_current_weight = user_dict.get("usercurrentweight", "")
    user_gender = user_dict.get("usergender", "")
    user_height = user_dict.get("userheight", "")
    selected_weight_goal = user_dict.get("selectedWeightGoal", "")

    formula_calculations = FormulaCalculations()
    str_user_tdee = str(formula_calculations.TDEE(
        calculate_age(user_birth_year),
        user_current_weight,
        user_height,
        user_gender,
    ))


    # Create the formatted string using the user details
    formatted_string = (
        "Please generate an Indian diet plan with Indian food & considering the following person information\n"
        "Age: {}\n"
        "Gender: {}\n"
        "Height: {} cm\n"
        "Weight: {} kg\n"
        "Weight Goal: {}\n"
    
        "Max Calories: {} Calories\n"
        "\n"
        "Please keep the output format as below\n"
        "\n"
        "<s>\n"
        "1. Breakfast\n"
        ".. meal info\n"
        "<e>\n"
        "<s>\n"
        "2. Lunch\n"
        ".. meal info\n"
        "<e>\n"
        "<s>\n"
        "3. Evening Snack\n"
        ".. meal info\n"
        "<e>\n"
        "<s>\n"
        "4. Dinner\n"
        ".. meal info\n"
        "<e>\n"
        "<s>\n"
        "5. Exercises\n"
        ".. exercises\n"
        "<e>\n"
        "\n"
        "The diet plan suggested food meets the maximum calorie limit.\n"
        "Please mention the calories consumed by meal and nutrition information too.\n"
        "Please separate using the <s> Meal <e> tag as provided in the template. "
        "Please ensure that the output maintains the same format as suggested.\n"
    ).format(
        calculate_age(user_birth_year),
        user_gender,
        user_height,
        user_current_weight,
        selected_weight_goal,
        str_user_tdee,
    )

    return formatted_string


if __name__ == "__main__":
    user_dict = {
        'age': 23.0,
        'gender': 'Female',
        'height': 172.0,
        'weight': 55.0,
        'goal': 'Loss Weight',
        'userbyear': '2003',
        'usercurrentweight': '70',
        'usergender': 'Female',
        'userheight': '165',
        'selectedWeightGoal': 'Lose Weight'
    }


    formatted_string = generate_formatted_string(user_dict)
    print(formatted_string)