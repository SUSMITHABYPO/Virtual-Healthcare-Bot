from langdetect import detect
from translate import Translator
import re

def detect_language(text):
    try:
        language_code = detect(text)
        return language_code
    except Exception as e:
        print(f"Language detection error: {e}")
        return None

def translate_to_english(text, source_language):
    try:
        translator = Translator(to_lang="en", from_lang=source_language)
        translation = translator.translate(text)
        return translation
    except Exception as e:
        print(f"Translation error: {e}")
        return None
 


def translate_to_original_language(text, target_language):

    try:
        translator = Translator(to_lang=target_language, from_lang="en")
        translation = translator.translate(text)
        return translation
    except Exception as e:
        print(f"Translation error: {e}")
        return None