from django.db import models
from datetime import datetime

class User(models.Model):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=80)
    email = models.EmailField(max_length=120)
    password = models.CharField(max_length=80)
