from django.shortcuts import render, HttpResponse,redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.hashers import make_password,check_password
from datetime import datetime
from home.models import User
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.csrf import csrf_exempt
import secrets
import random
from django.http import JsonResponse
from django.contrib import messages
import re
import home.ChatGPTApi as ChatGPTApi
import home.ChatGPTResultParser as ChatGPTResultParser
from home.Formulas import TDEE
from home.DiseasePredictor import predict_disease_from_symptom
from home.Translator import *

def generate_formatted_string(user_dict):
    age = user_dict.get('age', "")
    gender = user_dict.get('gender', "")
    height = user_dict.get('height', "")
    weight = user_dict.get('weight', "")
    goal = user_dict.get('goal', "")
    

    str_user_tdee = str(TDEE(
        age,
        weight,
        height,
        gender,

    ))

    
    # Create the formatted string using the user details
    formatted_string = (
        "Please generate an Indian diet plan with Indian food & considering the following person information\n"
        "Age: {}\n"
        "Gender: {}\n"
        "Height: {} cm\n"
        "Weight: {} kg\n"
        "Goal: {}\n"
        
        "Max Calories: {} Calories\n"
        "\n"
        "Please keep the output format as below\n"
        "\n"
        "<s>\n"
        "1. Breakfast\n"
        ".. meal info\n"
        "<e>\n"
        "<s>\n"
        "2. Lunch\n"
        ".. meal info\n"
        "<e>\n"
        "<s>\n"
        "3. Evening Snack\n"
        ".. meal info\n"
        "<e>\n"
        "<s>\n"
        "4. Dinner\n"
        ".. meal info\n"
        "<e>\n"
        "<s>\n"
        "5. Exercises\n"
        ".. exercises\n"
        "<e>\n"
        "\n"
        "The diet plan suggested food meets the maximum calorie limit.\n"
        "Please mention the calories consumed by meal and nutrition information too.\n"
        "Please separate using the <s> Meal <e> tag as provided in the template. "
        "Please ensure that the output maintains the same format as suggested.\n"
    ).format(
        age,
        gender,
        height,
        weight,
        goal,
        str_user_tdee,
    )

    return formatted_string



regex = '^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$'

WELCOME_GREET = [
    "Welcome to Virtual Healthcare Bot","Welcome to Virtual Healthcare Bot"
]



def index(request):
    return render(request, 'index.html')




def make_token():
    """
    Creates a cryptographically-secure, URL-safe string
    """
    return secrets.token_urlsafe(16) 

def index_auth(request):
    my_id = make_token()
    userSession[my_id] = -1
    return render(request, 'index_auth.html', {'sessionId': my_id})


@csrf_protect
def register(request):
    if request.method == "POST":
        uname = request.POST.get('uname')
        mail = request.POST.get('mail')
        passw = request.POST.get('passw')
        
        register = User(username=uname, email=mail, password=passw)
        register.save()

        return redirect('login')  
    return render(request, 'register.html')


def signupngo(request):
    return render(request, 'signupngo.html') 

@csrf_protect
def login(request):
    if request.method == "POST":
        uname = request.POST.get("uname")
        passw = request.POST.get("passw")

        # Validate form data as needed
        login = User.objects.filter(username=uname, password=passw).first()

        if login is not None:
            return redirect('index_auth')
        
    return render(request, 'login.html')



all_result = {
    'age':0,
    'gender':'',
    'height':0,
    'weight':0,
    'goal':0,    
    'symptoms':[],
}




def getSuggestedMeal(caloric_goal):


    # Divide caloric goal into three meals and snacks
    breakfast_cal = int(caloric_goal * 0.2)
    lunch_cal = int(caloric_goal * 0.30)
    dinner_cal = int(caloric_goal * 0.35)
    snack_cal = int(caloric_goal * 0.15)

    # Generate a list of foods that meet user's nutritional needs and preferences
    breakfast_food_list = []
    lunch_food_list = []
    dinner_food_list = []
    snacks_food_list = []

    for food in food_dict:
        if 'breakfast' in  food['meal_time'].lower():
            breakfast_food_list.append(food)
        if 'lunch' in  food['meal_time'].lower():
            lunch_food_list.append(food)
        if 'dinner' in  food['meal_time'].lower():
            dinner_food_list.append(food)
        if 'snack' in  food['meal_time'].lower():
            snacks_food_list.append(food)


    # Create a meal plan for the user
    meal_plan = {
        'breakfast': [],
        'lunch': [],
        'dinner': [],
        'snacks': []
    }


    for meal_type in meal_plan:
        remaining_cal = 0
        while remaining_cal < breakfast_cal and meal_type == 'breakfast' and len(breakfast_food_list) > 0:
            food = random.choice(breakfast_food_list)
            if food['calories'] <= breakfast_cal - remaining_cal:
                meal_plan[meal_type].append(food)
                remaining_cal += food['calories']
                breakfast_food_list.remove(food)
            else:
                breakfast_food_list.remove(food)


        while remaining_cal < lunch_cal and meal_type == 'lunch' and len(lunch_food_list) > 0:
            food = random.choice(lunch_food_list)
            if food['calories'] <= lunch_cal - remaining_cal:
                meal_plan[meal_type].append(food)
                remaining_cal += food['calories']
                lunch_food_list.remove(food)
            else:
                lunch_food_list.remove(food)



        while remaining_cal < dinner_cal and meal_type == 'dinner' and len(dinner_food_list) > 0:
            food = random.choice(dinner_food_list)
            if food['calories'] <= dinner_cal - remaining_cal:
                meal_plan[meal_type].append(food)
                remaining_cal += food['calories']
                dinner_food_list.remove(food)
            else:
                dinner_food_list.remove(food)



        while remaining_cal < snack_cal and meal_type == 'snacks' and len(snacks_food_list) > 0:
            food = random.choice(snacks_food_list)
            if food['calories'] <= snack_cal - remaining_cal:
                meal_plan[meal_type].append(food)
                remaining_cal += food['calories']
                snacks_food_list.remove(food)
            else:
                snacks_food_list.remove(food)


    print('\nBreakfast:',breakfast_cal)
    
    text = ""
    text += "<b>Breakfast:</b><br>";
    for food in meal_plan['breakfast']:
        text += "<br>"
        text += "  Food Name :" +food['name'] + "<br>"
        text += "  Amount    : " + food['serving_size']+ "<br>"    
    text += "<b><br>Total Breakfast Calories : " + str("%.1f" % (breakfast_cal)) + "</b><br><br>"


    text += "<b>Lunch:</b><br>";
    for food in meal_plan['lunch']:
        text += "<br>"
        text += "  Food Name :" +food['name'] + "<br>"
        text += "  Amount    : " + food['serving_size']+ "<br>"    
    text += "<b><br>Total Lunch Calories : " + str("%.1f" % (lunch_cal)) + "</b><br><br>"


    text += "<b>Snacks:</b><br>";
    for food in meal_plan['snacks']:
        text += "<br>"
        text += "  Food Name :" +food['name'] + "<br>"
        text += "  Amount    : " + food['serving_size']+ "<br>"    
    text += "<b><br>Total Snacks Calories : " + str("%.1f" % (snack_cal)) + "</b><br><br>"



    text += "<b>Dinner:</b><br>";
    for food in meal_plan['dinner']:
        text += "<br>"
        text += "  Food Name :" +food['name'] + "<br>"
        text += "  Amount    : " + food['serving_size']+ "<br>"    
    text += "<b><br>Total Dinner Calories : " + str("%.1f" % (dinner_cal)) + "</b><br><br>"


        
    text += "<br>=================<br>"
    text += "<b>Total Calories : " +str(caloric_goal) + "</b><br>"
    text += "=================";
    return text;


userSession = {}
users = []
global breakfast_list,lunch_list,evening_snack_list,dinner_list,exercises_list
breakfast_list,lunch_list,evening_snack_list,dinner_list,exercises_list = [],[],[],[],[]

@csrf_exempt  # This decorator is used for demonstration. In production, ensure proper CSRF protection.
def chat_msg(request):
    global breakfast_list,lunch_list,evening_snack_list,dinner_list,exercises_list

    if request.method == "POST":
        user_message = request.GET.get("message")
        sessionId = request.GET.get("sessionId")
 
        detected_language = detect_language(user_message)

        if detected_language:
            print(f"Detected Language Code: {detected_language}")
            user_message = translate_to_english(user_message, detected_language)
            print(user_message)

        

        rand_num = random.randint(0, 1)
        response = []

        if user_message == "undefined":
            response.append(WELCOME_GREET[rand_num])
            


        currentState = userSession.get(sessionId)


        if user_message=="generate diet plan":
            currentState = 100
            userSession[sessionId] = 100

        if user_message=="find disease":
            currentState = 201
            userSession[sessionId] = 201
        
        
        if currentState==-1:
           
            response.append("Hello User! Tell me how can I help you?") 
            response.append("Bot can provide general health information, diet plan, predicting disease")
            userSession[sessionId] = userSession.get(sessionId) +1

        if currentState==0:
            user_message_to_gpt = "Hi,"+user_message+"\nNote: Please keep response answer in 1 or 2 line only."
            print(user_message_to_gpt)
            result  = ChatGPTApi.ChatGPTApi.run(user_message_to_gpt)
            response.append(ChatGPTResultParser.ChatGPTResultParser.parse_result(result))
            response.append("Bot can provide general health information, diet plan, predicting disease")
            
        if currentState==100:           
            response.append("Please Mention your age?")
            userSession[sessionId] = userSession.get(sessionId) +1

        if currentState==101:
            pattern = r'\d+'
            result = re.findall(pattern, user_message)
            if len(result)==0:
                response.append("Invalid input. Provide valid age.")
                
            else:                
                all_result['age'] = float(result[0])                
                response.append("Please Mention Your gender ?")            
                response.append("Male")
                response.append("Female")
                userSession[sessionId] = userSession.get(sessionId) +1

        if currentState==102:
            if 'fe' in user_message.lower():
                all_result['gender'] = 'Female'
            else:
                all_result['gender'] = 'Male'
            response.append("Mention your height (in centimeter, cm).")            
            userSession[sessionId] = userSession.get(sessionId) +1

        if currentState==103:
            pattern = r'\d+'
            result = re.findall(pattern, user_message)
            if len(result)==0:
                response.append("Invalid input. Please provide valid height")
            else:                
                all_result['height'] = float(result[0])                
                response.append("Mention your weight (in kilogram, kg).")            
                userSession[sessionId] = userSession.get(sessionId) +1

        if currentState==104:
            pattern = r'\d+'
            result = re.findall(pattern, user_message)
            if len(result)==0:
                response.append("Invalid input. Please provide valid weight")
            else:                
                all_result['weight'] = float(result[0])                
                response.append("Please Select you weight goal")   
                response.append("1. Loss Weight")          
                response.append("2. Gain Weight")          
                response.append("3. Maintain Weight")       
                userSession[sessionId] = userSession.get(sessionId) +1

        if currentState==105:
            if '1' in user_message.lower() or 'loss' in user_message.lower():
                all_result['goal'] = 'Loss Weight'
            elif '2' in user_message.lower() or 'gain' in user_message.lower():
                all_result['goal'] = 'Gain Weight'
            elif '3' in user_message.lower() or 'maintain' in user_message.lower():
                all_result['goal'] = 'Maintain Weight'           
                 

            


            # Create user_details object and add to list
            print(all_result)
            formatted_string = generate_formatted_string(all_result)
            result  = ChatGPTApi.ChatGPTApi.run(formatted_string)


            # Parse the result
            content = ChatGPTResultParser.ChatGPTResultParser.parse_result(result)

            # Extract meal lists
            if content:
                (
                    breakfast_list,
                    lunch_list,
                    evening_snack_list,
                    dinner_list,
                    exercises_list,
                ) = ChatGPTResultParser.extract_meal_lists(content)

                # Display the extracted content
                print("Content:", content)
                print("Breakfast List:", breakfast_list)
                print("Lunch List:", lunch_list)
                print("Evening Snack List:", evening_snack_list)
                print("Dinner List:", dinner_list)
                print("Exercises List:", exercises_list)

                response.append("<b>Suggested Meal Plan</b>")   

                response.append("")   
                response.append("<b>Breakfast</b>")
                for meal in breakfast_list:
                    response.append(meal)   

                response.append("")                   
                response.append("<b>Lunch</b>")
                for meal in lunch_list:
                    response.append(meal)   
                
                response.append("")   
                response.append("<b>Evening Snack</b>")
                for meal in evening_snack_list:
                    response.append(meal)   
                
                response.append("")   
                response.append("<b>Dinner</b>")
                for meal in dinner_list:
                    response.append(meal)   
                
                response.append("")   
                response.append("<b>Exercises</b>")
                for meal in exercises_list:
                    response.append(meal)   
                    
                response.append('''<a href="http://127.0.0.1:8000/meal_list" target="_blank" style="display: inline-block; padding: 10px 20px; font-size: 16px; text-align: center; text-decoration: none; background-color: #4CAF50; color: white; border: 2px solid #4CAF50; border-radius: 5px; transition: background-color 0.3s ease, color 0.3s ease;" onmouseover="this.style.backgroundColor='#45a049'; this.style.color='white'" onmouseout="this.style.backgroundColor='#4CAF50'; this.style.color='white'">Go to Meal List</a>''')    
                userSession[sessionId] = 0
  
        if currentState==201:    
            response.append("Can you tell me the one by one name of the symptoms you are experiencing?")         
            userSession[sessionId] = userSession.get(sessionId) +1

        if currentState==202:
            
            all_result['symptoms'].extend(user_message.split(","))           
            response.append(" You can type more symptom names to make it more accurate, or you can type 'predict disease'.")            
            userSession[sessionId] = userSession.get(sessionId) +1


        if currentState==203:

            if  user_message == "predict disease":
                print(all_result['symptoms'])
                disease,type = predict_disease_from_symptom(all_result['symptoms'])  
                response.append("<b>The following diseases may be causing your discomfort</b>")
                response.append("<b>Opinion 1</b>")
                response.append(disease)
                response.append(f'<a href="https://www.google.com/search?q={type} disease hospital near me" target="_blank">Search Hospitals</a>')   
                user_message_to_gpt = "Hi, I am experiencing the following disease symptoms "+str(all_result['symptoms'])+". Can you tell me which disease I may be suffering from and what preventions and precautions I should take for it?  Note: Please keep response answer in 5 or 6 line only."
                print(user_message_to_gpt)
                result  = ChatGPTApi.ChatGPTApi.run(user_message_to_gpt)
                response.append("<b>Opinion 2</b>")
                response.append(ChatGPTResultParser.ChatGPTResultParser.parse_result(result))   
                response.append("Tell me how can I help you?") 
                response.append("Bot can provide general health information, diet plan, predicting disease")
                userSession[sessionId] = 0

            else:
                
                all_result['symptoms'].extend(user_message.split(","))           
                response.append(" You can type more symptom names to make it more accurate, or you can type 'predict disease'.")            
                userSession[sessionId] = userSession.get(sessionId) +1



    
        if currentState==204:
            if  user_message == "predict disease":
                print(all_result['symptoms'])
                disease,type = predict_disease_from_symptom(all_result['symptoms'])  
                response.append("<b>The following diseases may be causing your discomfort</b>")
                response.append("<b>Opinion 1</b>")
                response.append(disease)
                response.append(f'<a href="https://www.google.com/search?q={type} disease hospital near me" target="_blank">Search Hospitals</a>')   
                user_message_to_gpt = "Hi, I am experiencing the following disease symptoms "+str(all_result['symptoms'])+". Can you tell me which disease I may be suffering from and what preventions and precautions I should take for it?  Note: Please keep response answer in 5 or 6 line only."
                print(user_message_to_gpt)
                result  = ChatGPTApi.ChatGPTApi.run(user_message_to_gpt)
                response.append("<b>Opinion 2</b>")
                response.append(ChatGPTResultParser.ChatGPTResultParser.parse_result(result))   
                response.append("Tell me how can I help you?") 
                response.append("Bot can provide general health information, diet plan, predicting disease")
                userSession[sessionId] = 0


            else:                
                all_result['symptoms'].extend(user_message.split(","))              
                response.append(" You can type more symptom names to make it more accurate, or you can type 'predict disease'.")            
                userSession[sessionId] = userSession.get(sessionId) +1


        if currentState==205:    
            if  user_message == "predict disease":
                print(all_result['symptoms'])
                disease,type = predict_disease_from_symptom(all_result['symptoms'])  
                response.append("<b>The following diseases may be causing your discomfort</b>")
                response.append("<b>Opinion 1</b>")
                response.append(disease)
                response.append(f'<a href="https://www.google.com/search?q={type} disease hospital near me" target="_blank">Search Hospitals</a>')   
                user_message_to_gpt = "Hi, I am experiencing the following disease symptoms "+str(all_result['symptoms'])+". Can you tell me which disease I may be suffering from and what preventions and precautions I should take for it?  Note: Please keep response answer in 5 or 6 line only."
                print(user_message_to_gpt)
                result  = ChatGPTApi.ChatGPTApi.run(user_message_to_gpt)
                response.append("<b>Opinion 2</b>")
                response.append(ChatGPTResultParser.ChatGPTResultParser.parse_result(result))   
                response.append("Tell me how can I help you?") 
                response.append("Bot can provide general health information, diet plan, predicting disease")
                userSession[sessionId] = 0

            else:                
                all_result['symptoms'].extend(user_message.split(","))               
                response.append(" You can type more symptom names to make it more accurate, or you can type 'predict disease'.")            
                userSession[sessionId] = userSession.get(sessionId) +1



        if currentState==206:
            if  user_message == "predict disease":
                print(all_result['symptoms'])
                disease,type = predict_disease_from_symptom(all_result['symptoms'])  
                response.append("<b>The following diseases may be causing your discomfort</b>")
                response.append("<b>Opinion 1</b>")
                response.append(disease)
                response.append(f'<a href="https://www.google.com/search?q={type} disease hospital near me" target="_blank">Search Hospitals</a>')   
                user_message_to_gpt = "Hi, I am experiencing the following disease symptoms "+str(all_result['symptoms'])+". Can you tell me which disease I may be suffering from and what preventions and precautions I should take for it?  Note: Please keep response answer in 5 or 6 line only."
                print(user_message_to_gpt)
                result  = ChatGPTApi.ChatGPTApi.run(user_message_to_gpt)
                response.append("<b>Opinion 2</b>")
                response.append(ChatGPTResultParser.ChatGPTResultParser.parse_result(result))   
                response.append("Tell me how can I help you?") 
                response.append("Bot can provide general health information, diet plan, predicting disease")
                userSession[sessionId] = 0
            else:               
                all_result['symptoms'].extend(user_message.split(","))                
                response.append(" You can type more symptom names to make it more accurate, or you can type 'predict disease'.")            
                userSession[sessionId] = userSession.get(sessionId) +1




        if currentState==207:    
            if  user_message == "predict disease":
                print(all_result['symptoms'])
                disease,type = predict_disease_from_symptom(all_result['symptoms'])  
                response.append("<b>The following diseases may be causing your discomfort</b>")
                response.append("<b>Opinion 1</b>")
                response.append(disease)
                response.append(f'<a href="https://www.google.com/search?q={type} disease hospital near me" target="_blank">Search Hospitals</a>')   
                user_message_to_gpt = "Hi, I am experiencing the following disease symptoms "+str(all_result['symptoms'])+". Can you tell me which disease I may be suffering from and what preventions and precautions I should take for it?  Note: Please keep response answer in 5 or 6 line only."
                print(user_message_to_gpt)
                result  = ChatGPTApi.ChatGPTApi.run(user_message_to_gpt)
                response.append("<b>Opinion 2</b>")
                response.append(ChatGPTResultParser.ChatGPTResultParser.parse_result(result))   
                response.append("Tell me how can I help you?") 
                response.append("Bot can provide general health information, diet plan, predicting disease")
                userSession[sessionId] = 0

            else:               
                all_result['symptoms'].extend(user_message.split(","))                
                response.append(" You can type more symptom names to make it more accurate, or you can type 'predict disease'.")            
                userSession[sessionId] = userSession.get(sessionId) +1



        if currentState>207 and currentState<290:
            print(all_result['symptoms'])
            disease,type = predict_disease_from_symptom(all_result['symptoms'])  
            response.append("<b>The following diseases may be causing your discomfort</b>")
            response.append("<b>Opinion 1</b>")
            response.append(disease)
            response.append(f'<a href="https://www.google.com/search?q={type} disease hospital near me" target="_blank">Search Hospitals</a>')   
            user_message_to_gpt = "Hi,I am experiencing the following disease symptoms "+str(all_result['symptoms'])+". Can you tell me which disease I may be suffering from and what preventions and precautions I should take for it?  Note: Please keep response answer in 5 or 6 line only."
            print(user_message_to_gpt)
            result  = ChatGPTApi.ChatGPTApi.run(user_message_to_gpt)
            response.append("<b>Opinion 2</b>")
            response.append(ChatGPTResultParser.ChatGPTResultParser.parse_result(result))   
            response.append("Tell me how can I help you?") 
            response.append("Bot can provide general health information, diet plan, predicting disease")
            userSession[sessionId] = 0
        
        print(response)

        return JsonResponse({'status': 'OK', 'answer': response})

    return JsonResponse({'status': 'Error', 'message': 'Invalid request method'})

 
def meal_list(request):

    global breakfast_list,lunch_list,evening_snack_list,dinner_list,exercises_list

    return render(request, 'meal_list.html', {
        'breakfast_list': breakfast_list,
        'lunch_list': lunch_list,
        'evening_snack_list': evening_snack_list,
        'dinner_list': dinner_list,
        'exercises_list': exercises_list,
    })

