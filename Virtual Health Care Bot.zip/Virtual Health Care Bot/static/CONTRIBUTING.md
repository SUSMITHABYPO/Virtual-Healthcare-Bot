# Contributing

Contribute per PR (Pull Request), if you have an Idea or found a bug, open a Issue.

## Pull Request Process

1. Create a Pull Request and it will be reviewed